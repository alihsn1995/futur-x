<?php
$servername='localhost';
$username='root';
$password=null;
$dbname='coverage';
$conn=new mysqli($servername,$username ,$password,$dbname);
if($conn->connect_error){
    die('خطا');
}
echo"تم الاتصال";
?>